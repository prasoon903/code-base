STEPS TO DEPLOY:

1. Take the backup of all scripts in MilkReplaySchedulesUtility folder.
2. Add variables in the Setup.py according to the environment as per Setup_Delta.py.
3. Install boto3 python library (python -m pip install boto3).
4. Install pandas python library (python -m pip install pandas).
5. Install numpy python library (python -m pip install numpy).
6. Place the new scripts on the same location.
7. Make a new folder "EXCEPTION" under the directory //dump/MilkReplaySchedules folder.