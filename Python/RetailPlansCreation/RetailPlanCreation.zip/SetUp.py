class SetUp:
    CI_DB = "PP_CI"
    CL_DB = "PP_CL"
    CAuth_DB = "PP_CAuth"
    SERVERNAME = "XEON-S8"
    LogDir = "E:\Python\RetailPlansCreation\LOG"