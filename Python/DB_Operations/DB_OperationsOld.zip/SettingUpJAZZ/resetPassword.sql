UPDATE PP_JAZZ_CL..UserInformation SET usrPassword=convert(varbinary,'#bqhEnrY5ii/CDE90'),
usrErnLogin='0',usrStatus = '0',PasswordDate = '2037-10-27 00:06:04.000' WHERE usrid IN('MayorsCall','CreditStacksCall','PortalSuperUser','BCAdmin','FinalAdmin','AOCAdmin','AuthUser','ServiceUser')


--select usrPassword, * from PP_CL..UserInformation where usrid IN('MayorsCall','CreditStacksCall','PortalSuperUser','BCAdmin','FinalAdmin','AOCAdmin','AuthUser','ServiceUser')