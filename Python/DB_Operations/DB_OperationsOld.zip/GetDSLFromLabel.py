from logging import exception
import time
import subprocess
from SetUp import SetUp
from ConnectDB import ConnectDB
from Logger import get_logger
import datetime
import os
import shutil

S1 = SetUp()

LogDateTime = datetime.datetime.now()

# LOG_FILE = S1.LogDir + "\\" + "COPY_DSL_LOG_" + str(LogDateTime.strftime("%Y%m%d%H%M%S")) + ".log"

# MessageLogger = get_logger(LOG_FILE)


def CopyDSLs(MessageLogger, Label):
    LabelPath = "\\\\" + S1.LabelPathPrefix + "\\" + Label + "\\" + S1.DSLPathSuffix
    MessageLogger.info("LabelPath: " + str(LabelPath))
    PathToCopyDSL = S1.EnvDSLLocation + "\\" + Label
    MessageLogger.info("LabelPath: " + LabelPath)
    MessageLogger.info("PathToCopyDSL: " + PathToCopyDSL)

    if os.path.isdir(PathToCopyDSL):
        MessageLogger.info("Folder already exists, PathToCopyDSL: " + str(PathToCopyDSL))
    else:
        os.mkdir(PathToCopyDSL) 
        MessageLogger.info("Directory '% s' created" % PathToCopyDSL)
        CopyDSLsToLocation(MessageLogger, LabelPath, PathToCopyDSL)


def CopyDSLsToLocation(MessageLogger, FromPath, ToPath):
    MessageLogger.info("FromPath: " + FromPath)
    MessageLogger.info("ToPath: " + ToPath)
    
    if os.path.isdir(FromPath):
        try:
            CopyScript = "XCopy " + FromPath + " " + ToPath + " /E/H/C/I"
            MessageLogger.info("CopyScript :: " + CopyScript)
            subprocess.run(CopyScript)
            # shutil.copy(FromPath, ToPath)
            MessageLogger.info("DSLs copied successfully")
        except exception:
            MessageLogger.error("FATAL :: Error in copying DSLs :: ", exc_info=True)
    else:
        MessageLogger.info("Directory does not exists, FromPath :: " + FromPath)
    

def MoveDSLsToLocation(MessageLogger, FromPath, ToPath):
    MessageLogger.info("FromPath: " + FromPath)
    MessageLogger.info("ToPath: " + ToPath)

    if os.path.isdir(FromPath):
        try:
            # MoveScript = "move " + FromPath + " " + ToPath
            # MoveScript = "XCopy " + FromPath + " " + ToPath + " /E/H/C/I"
            # MessageLogger.info("MoveScript :: ", MoveScript)
            # subprocess.run(MoveScript)
            # Delete = "rmdir " + FromPath
            # subprocess.run(Delete)
            shutil.move(FromPath, ToPath)
            MessageLogger.info("DSLs moved successfully")
        except exception:
            MessageLogger.error("FATAL :: Error in moving DSLs :: ", exc_info=True) 
    else:
        MessageLogger.info("Directory doesnot exists, FromPath :: ", FromPath)   


'''
if __name__ == "__main__":
    MessageLogger.info("PROCESS STARTS")

    ProcessType = 0
    POD = 0
    Label = ""
    LabelPath = ""
    Location = ""

    try:
        if os.path.isdir(S1.EnvDSLLocation):
            while True:
                Label = str(input("ENTER LABEL: "))
                LabelPath = "\\\\" + S1.LabelPathPrefix + "\\" + Label + "\\" + S1.DSLPathSuffix
                if os.path.isdir(LabelPath):
                    # MessageLogger.info("LabelPath: " + str(LabelPath))
                    CopyDSLs(MessageLogger, Label)                    
                    break
                else:
                    MessageLogger.info("INVALID PATH: " + str(LabelPath))
        else:
            MessageLogger.info("Environment is not valid: " + S1.EnvDSLLocation)
    except exception:
        MessageLogger.error("FATAL :: ", exc_info=True)

'''