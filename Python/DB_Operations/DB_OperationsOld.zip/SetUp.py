class SetUp:
    CI_DB_POD1 = "PP_CI"
    CI_SEC_DB_POD1 = "PP_CI_Secondary"
    CL_DB_POD1 = "PP_CL"
    CAuth_DB_POD1 = "PP_CAuth"
    CC_DB_POD1 = "PP_CC"
    CoreApp_DB_POD1 = "PP_CoreApp"
    CoreCredit_DB_POD1 = "PP_CoreCredit"
    SERVERNAME_POD1 = "XEON-S8"

    CI_DB_POD2 = "PP_POD2_CI"
    CI_SEC_DB_POD2 = "PP_POD2_CI_Secondary"
    CL_DB_POD2 = "PP_POD2_CL"
    CAuth_DB_POD2 = "PP_POD2_CAuth"
    CC_DB_POD2 = "PP_POD2_CC"
    CoreApp_DB_POD2 = "PP_POD2_CoreApp"
    CoreCredit_DB_POD2 = "PP_POD2_CoreCredit"
    SERVERNAME_POD2 = "XEON-S9"

    GetJazzEnv = 1  # 1-YES/0-NO
    JAZZ_CI_DB = "PP_JAZZ_CI"
    JAZZ_CI_SEC_DB = "PP_JAZZ_CI_Secondary"
    JAZZ_CL_DB = "PP_JAZZ_CL"
    JAZZ_CAuth_DB = "PP_JAZZ_CAuth"
    JAZZ_CC_DB = "PP_JAZZ_CC"
    JAZZ_CoreApp_DB = "PP_JAZZ_CoreApp"
    JAZZ_CoreCredit_DB = "PP_JAZZ_CoreCredit"
    JAZZ_SERVERNAME = "XEON-S8"
    JAZZ_MDF = "\\\\Xeon-s8\dfs\Prasoon Parashar\JazzDB\MDF"
    JAZZ_LDF = "\\\\Xeon-s8\dfs\Prasoon Parashar\JazzDB\LDF"

    LogDir = "E:\Python\DB_Operations\LOG"

    LabelPathPrefix = "xeon-s8\Labels_PlatAndJazz"

    LabelPathSuffix_POD1 = "Application\DB\MasterDB_New"
    LabelPathSuffix_POD2 = "Application\DB\MasterDB_POD2"
    JAZZ_LabelPathSuffix = "Application\DB\Jazz_MasterDB_New"

    DSLPathSuffix = "Application\DSL"
    EnvDSLLocation = "D:\BankCard\DSLs"
    BackupLocation = "D:\BankCard\DSLs\Backup"

    AdjustDSLs = 0
    DSLAdjusmentLoc = "E:\Python\DB_Operations\__ClientDSL"
    
    SQL = "E:\Python\DB_Operations"

    DBBackupLocation_POD1 = "\\\\Xeon-s8\dfs\Prasoon Parashar\\backup"
    DBBackupLocation_POD2 = "\\\\Xeon-s9\dfs\Prasoon Parashar\\backup"
    JAZZ_DBBackupLocation = "\\\\Xeon-s8\dfs\Prasoon Parashar\\JazzDB\\backup"

    Driver = "{ODBC Driver 17 for SQL Server}"
